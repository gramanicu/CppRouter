// Copyright Grama Nicolae 2020
#include "Router.hpp"

int main(int argc, char *argv[]) {
    Router server;
    server.runServer();

    return 0;
}